# 课时光 · Flutter MVP V8

面向 Android / iOS 的个人课程表应用。当前版本在 V7 的本地 PDF 导入、逐条纠错和周视图基础上，加入多学期归档与单步导入撤销。

## 当前包含

- 周一至周日、1–11 节周视图；上午、下午、晚上只标记节次分段，不伪造具体上下课时间。
- 课程卡片按开始/结束节次纵向跨行显示；同一时间冲突的课程分列，不自动覆盖。
- 点击课程卡片编辑，长按删除。
- PDF 导入预览支持逐条编辑和删除固定时段、非固定时段课程。
- 连续周、单双周和离散指定周次解析；缺失字段和原始歧义文本会提示人工核对。
- 课程名称、星期、起止节次、周次、教师、校区、场地、类型、线上标记可编辑。
- 固定时段课程与非固定时段课程分别保存。
- **多学期独立存储**：学期下拉框切换课表；可手动新建学期。
- **PDF 学期自动归档**：能识别 PDF 学期时，导入到对应学期；未识别时导入当前学期，不猜测学期。
- **导入前快照与单步撤销**：导入前保存目标学期原数据；撤销会恢复旧数据。若导入创建了新学期，撤销会删除该新学期并返回原先正在查看的学期。
- 切换学期不清除撤销记录；后续手动编辑/删除/添加课程会使撤销记录失效，避免撤销覆盖用户后续修改。
- V7 旧版 `courses` / `unscheduled_courses` SharedPreferences 数据会经课程模型白名单重新序列化后迁移到“旧课表（学期未标注）”，丢弃未知字段，不擅自推断其学期。
- 数据只保存在本机 SharedPreferences；不保存学生姓名、学号或原始 PDF。
- 保留 CSV / Excel 基础导入和手动添加课程。

## 本地存储结构

新数据写入单一键 `semester_archive_v1`，结构包含：
- `activeSemesterId`
- `semesters[]`：每学期独立的固定时段和非固定时段课程
- `lastImportUndo`：最近一次导入前的目标学期快照、导入目标和导入前活动学期

旧版键仅在成功写入新归档后移除。导入确认前不会改写存储；取消 PDF 预览不产生备份或数据变更。

## 武汉轻工大学真实样本基准

样本：2026–2027 学年第 1 学期，三页文字型 PDF，页面旋转 90 度。

脱敏黄金基准：
- 23 条固定星期/节次安排；
- 2 条非固定时段安排（认识实习、民族手工艺术线上课程）；
- 固定时段课程涉及 14 种课程名称；
- 第 11 周和第 12 周基准按真实星期列核对。

V5 修正星期坐标轴识别；V6 加入导入纠错与跨节卡片；V7 收紧周次字段提取；V8 加入多学期归档、旧数据迁移、导入备份与撤销。

## 运行与验证

源码 ZIP 只包含 Dart 源码、测试和文档，不包含 Flutter 自动生成的 `android/`、`ios/` 平台工程目录。首次使用时在项目根目录执行：

```bash
flutter create --platforms=android,ios --org com.example .
```

`com.example` 仅适合本地试运行；正式发布前应改为自己控制的反向域名标识。iOS 工程生成和构建需要 macOS 与 Xcode。

在已安装 Flutter 的环境执行：

```bash
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build apk --release
```

iOS 构建：

```bash
flutter build ios --release
```

本轮执行环境未安装 Flutter / Dart SDK，因此没有声称以上命令已执行或构建成功。详见 `VALIDATION_REPORT.md`。

## 许可注意

`syncfusion_flutter_pdf` 是商业组件。发布或分发前，请确认符合 Syncfusion Community License 条件，或取得商业许可。

## 尚未完成 / 未验证

- Flutter/Dart 格式化、静态分析、单元测试尚未运行。
- 多学期下拉、导入撤销及旧数据迁移尚未在真机交互验证。
- Syncfusion 对旋转 PDF 的实际设备坐标输出仍需与黄金基准端到端对照。
- Android APK 和 iOS 构建尚未生成。
- 当前为单机本地存储，没有云同步、跨设备备份或账号体系。
- 非固定时段课程仍独立显示，不会擅自安排进某一天某一节。


## V9 test coverage added

- Widget tests for semester dropdown switching and persistence.
- Widget tests for creating a semester and switching to it.
- Widget test that the undo menu item is disabled without an import snapshot.
- Widget test for undo action and persisted archive state.
- Widget tests for the PDF import target notice: replacing an existing semester vs creating a new semester.
- Widget test for restoring the selected semester and undo availability after rebuilding the app widget.

Run on a machine with Flutter installed:

```bash
flutter pub get
dart format lib test
flutter analyze
flutter test
```

The widget tests have been authored but were not executed in the current environment because Flutter/Dart SDK is unavailable.


## Cloud Android APK build

See `CLOUD_ANDROID_BUILD.md`. A GitHub Actions workflow is provided at `.github/workflows/android.yml`; it runs checks and builds a release APK on GitHub-hosted runners.
