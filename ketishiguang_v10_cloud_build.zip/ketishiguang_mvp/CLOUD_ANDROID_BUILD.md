# 课时光 V10 云端 APK 构建

本项目包含 GitHub Actions 工作流：`.github/workflows/android.yml`。

## 云端构建方式
1. 将本目录中的 `ketishiguang_mvp` 项目上传到你自己的 GitHub 仓库（仓库根目录应直接包含 `pubspec.yaml`）。
2. 打开仓库的 **Actions** 页面，选择 **Android APK**，点击 **Run workflow**。
3. 等待工作流完成。它会生成 Android 工程、获取依赖、执行格式检查、静态分析和测试，再构建 release APK。
4. 在成功的运行记录底部 **Artifacts** 中下载 `ketishiguang-android-apk`，里面是 `app-release.apk`。

## 重要
- 这条路径不要求在你的电脑安装 Flutter 或 Android Studio；但需要一个 GitHub 账号和仓库，并由 GitHub 托管构建。
- 当前会先运行测试和分析；任何一步失败都会停止，不会上传一个未通过该流程的 APK。
- 当前工作环境不能访问外网，也没有 Flutter/Android SDK，因此这里无法直接运行云端工作流或声称 APK 已生成。
- 这不是 APK 文件，而是已配置云端构建的源码包。
