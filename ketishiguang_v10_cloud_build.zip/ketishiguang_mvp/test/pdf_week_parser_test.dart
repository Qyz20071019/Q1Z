import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:ketishiguang/import/pdf_course_importer.dart';

ImportedMeeting _meeting({
  String name = '测试课程',
  int weekday = 1,
  int start = 1,
  int end = 2,
  Set<int> weeks = const {1},
}) {
  return ImportedMeeting(
    courseName: name,
    weekday: weekday,
    startSection: start,
    endSection: end,
    weeks: weeks,
    teacher: '',
    room: '',
    campus: '',
    kind: '讲课',
    online: false,
    sourceText: '',
  );
}

void main() {
  group('周次解析', () {
    test('解析连续周、单双周和指定周', () {
      expect(PdfCourseImporter.parseWeekNumbers('1-10周,12-16周'),
          equals({1,2,3,4,5,6,7,8,9,10,12,13,14,15,16}));
      expect(PdfCourseImporter.parseWeekNumbers('1-15周（单）'),
          equals({1,3,5,7,9,11,13,15}));
      expect(PdfCourseImporter.parseWeekNumbers('2-16周(双)'),
          equals({2,4,6,8,10,12,14,16}));
      expect(PdfCourseImporter.parseWeekNumbers('第8周'), equals({8}));
      expect(PdfCourseImporter.parseWeekNumbers('10周,14周'), equals({10,14}));
      expect(PdfCourseImporter.parseWeekNumbers('1周、3周、5周'), equals({1,3,5}));
      expect(PdfCourseImporter.parseWeekNumbers('第2周、 第6周、 第10周'),
          equals({2,6,10}));
      expect(PdfCourseImporter.parseWeekNumbers('共15周/4-18周'),
          equals(Set<int>.from(List.generate(15, (i) => i + 4))));
      expect(
        PdfCourseImporter.extractWeekExpression(
          '(1-2节)2-16周(双)/校区:常青花园/教师:费会/教学班:CHEM2419-02',
          '(1-2节)'.length,
        ),
        '2-16周(双)',
      );
      expect(
        PdfCourseImporter.parseWeekNumbers(
          PdfCourseImporter.extractWeekExpression(
            '(5-6节)1-7周,9-12周/校区:常青花园/教学班:PHAR3220-02',
            '(5-6节)'.length,
          ),
        ),
        equals({1,2,3,4,5,6,7,9,10,11,12}),
      );
      expect(
        () => PdfCourseImporter.parseWeekNumbers('12-8周'),
        throwsFormatException,
      );
    });
  });

  group('PDF 坐标方向', () {
    test('识别样本 PDF 的星期轴为 Y 轴（页面旋转90度）', () {
      final headers = <int, ({double x, double y})>{
        1: (x: 69, y: 691),
        2: (x: 69, y: 587),
        3: (x: 69, y: 483),
        4: (x: 69, y: 379),
        5: (x: 69, y: 275),
        6: (x: 69, y: 171),
        7: (x: 69, y: 68),
      };
      expect(PdfCourseImporter.weekdayAxisUsesX(headers), isFalse);
    });

    test('兼容星期轴为 X 轴的横向 PDF', () {
      final headers = <int, ({double x, double y})>{
        1: (x: 150, y: 60),
        2: (x: 250, y: 60),
        3: (x: 350, y: 60),
        4: (x: 450, y: 60),
        5: (x: 550, y: 60),
        6: (x: 650, y: 60),
        7: (x: 750, y: 60),
      };
      expect(PdfCourseImporter.weekdayAxisUsesX(headers), isTrue);
    });

    test('根据星期标题中心找到最近列', () {
      final centers = {1: 691.0, 2: 587.0, 3: 483.0};
      expect(PdfCourseImporter.nearestWeekday(centers, 498), 3);
      expect(PdfCourseImporter.nearestWeekday(centers, 680), 1);
    });
  });

  group('真实课表黄金基准', () {
    late Map<String, dynamic> fixture;
    late List<ImportedMeeting> meetings;

    setUpAll(() async {
      final file = File('test/fixtures/expected_schedule.json');
      fixture = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
      meetings = (fixture['fixedMeetings'] as List)
          .map((item) {
            final m = Map<String, dynamic>.from(item as Map);
            return ImportedMeeting(
              courseName: m['courseName'] as String,
              weekday: m['weekday'] as int,
              startSection: m['startSection'] as int,
              endSection: m['endSection'] as int,
              weeks: (m['weeks'] as List).cast<int>().toSet(),
              teacher: m['teacher'] as String,
              room: m['room'] as String,
              campus: m['campus'] as String,
              kind: m['kind'] as String,
              online: false,
              sourceText: 'golden fixture',
            );
          })
          .toList();
    });

    test('样本包含23条固定时段记录和2条非固定时段课程', () {
      expect(fixture['semester'], '2026-2027学年第1学期');
      expect(meetings, hasLength(23));
      expect(fixture['unscheduled'], hasLength(2));
    });

    test('体育课第11周特殊教师与常规周次互斥', () {
      final pe = meetings.where((m) =>
          m.courseName == '大学体育3' && m.weekday == 1).toList();
      expect(pe, hasLength(2));
      final normal = pe.singleWhere((m) => m.teacher == '徐珊');
      final override = pe.singleWhere((m) => m.teacher == '赵邦杰');
      expect(normal.weeks.contains(11), isFalse);
      expect(override.weeks, equals({11}));
    });

    test('有机化学III周四单双周课程与周六每周课程分别保留', () {
      final organic = meetings.where((m) => m.courseName == '有机化学III').toList();
      expect(organic, hasLength(2));
      expect(organic.any((m) => m.weekday == 4 &&
          m.startSection == 1 && m.weeks.contains(12)), isTrue);
      expect(organic.any((m) => m.weekday == 6 &&
          m.startSection == 5 && m.weeks.contains(12)), isTrue);
    });

    test('化工原理实验Ⅱ的四种指定周次和节次分别保留', () {
      final labs = meetings.where((m) => m.courseName == '化工原理实验Ⅱ').toList();
      expect(labs, hasLength(4));
      expect(labs.map((m) => '${m.startSection}-${m.endSection}:${m.weeks.join(",")}')
          .toSet(), containsAll({
        '5-7:8',
        '5-7:10,14',
        '5-8:6',
        '5-8:12',
      }));
      expect(labs.every((m) => m.weekday == 4), isTrue);
    });

    test('第11周和第12周的关键周视图按真实星期列还原', () {
      final week11 = meetings.where((m) => m.weeks.contains(11)).toList();
      final week12 = meetings.where((m) => m.weeks.contains(12)).toList();

      expect(week11.any((m) => m.courseName == '生物化学实验' &&
          m.weekday == 3 && m.startSection == 7 && m.endSection == 9), isTrue);
      expect(week11.any((m) => m.courseName == '有机化学III' &&
          m.weekday == 6 && m.startSection == 5), isTrue);
      expect(week11.any((m) => m.courseName == '有机化学III' &&
          m.weekday == 4 && m.startSection == 1), isFalse);

      expect(week12.any((m) => m.courseName == '大学体育3' &&
          m.weekday == 1 && m.teacher == '徐珊'), isTrue);
      expect(week12.any((m) => m.courseName == '有机化学III' &&
          m.weekday == 4 && m.startSection == 1 && m.endSection == 2), isTrue);
      expect(week12.any((m) => m.courseName == '化工原理实验Ⅱ' &&
          m.weekday == 4 && m.startSection == 5 && m.endSection == 8), isTrue);
    });

    test('按修正后的真实列坐标，样本23条记录没有时间冲突', () {
      expect(PdfCourseImporter.findConflicts(meetings, maxWeek: 20), isEmpty);
    });
  });

  test('冲突检测仍能报告真实重叠节次且不改动原记录', () {
    final first = _meeting(
      name: '课程甲', weekday: 3, start: 1, end: 2, weeks: {2, 4},
    );
    final second = _meeting(
      name: '课程乙', weekday: 3, start: 2, end: 3, weeks: {4, 6},
    );
    final conflicts = PdfCourseImporter.findConflicts([first, second], maxWeek: 8);
    expect(conflicts, hasLength(1));
    expect(conflicts.single.week, 4);
    expect(conflicts.single.overlapStartSection, 2);
    expect(conflicts.single.overlapEndSection, 2);
    expect(first.courseName, '课程甲');
    expect(second.courseName, '课程乙');
  });
}
