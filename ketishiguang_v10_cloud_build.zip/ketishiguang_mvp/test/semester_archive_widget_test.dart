import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ketishiguang/main.dart';
import 'package:ketishiguang/data/semester_archive.dart';
import 'package:ketishiguang/widgets/import_target_notice.dart';

Future<void> pumpApp(WidgetTester tester) async {
  await tester.pumpWidget(const ClassTimeApp());
  await tester.pumpAndSettle();
}

void seedArchive(SemesterArchive archive) {
  SharedPreferences.setMockInitialValues({
    'semester_archive_v1': jsonEncode(archive.toJson()),
  });
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('课时光多学期界面', () {
    setUp(() {
      SharedPreferences.setMockInitialValues({});
    });


    testWidgets('PDF识别到已有学期时显示覆盖警告和撤销提示', (tester) async {
      await tester.pumpWidget(const MaterialApp(
        home: Scaffold(
          body: ImportTargetNotice(
            targetName: '2026-2027学年第1学期',
            targetExists: true,
          ),
        ),
      ));

      expect(
        find.textContaining('导入目标：2026-2027学年第1学期'),
        findsOneWidget,
      );
      expect(find.textContaining('将替换该学期原课表'), findsOneWidget);
      expect(find.textContaining('可撤销'), findsOneWidget);
    });

    testWidgets('PDF识别到新学期时提示将新建而非覆盖', (tester) async {
      await tester.pumpWidget(const MaterialApp(
        home: Scaffold(
          body: ImportTargetNotice(
            targetName: '2027-2028学年第1学期',
            targetExists: false,
          ),
        ),
      ));

      expect(find.textContaining('2027-2028学年第1学期'), findsOneWidget);
      expect(find.textContaining('将新建学期'), findsOneWidget);
      expect(find.textContaining('将替换该学期原课表'), findsNothing);
    });

    testWidgets('学期下拉切换会持久化当前学期', (tester) async {
      seedArchive(SemesterArchive(
        activeSemesterId: 's1',
        semesters: [
          SemesterData(id: 's1', name: '2026-2027学年第1学期'),
          SemesterData(id: 's2', name: '2026-2027学年第2学期'),
        ],
      ));

      await pumpApp(tester);
      expect(find.text('2026-2027学年第1学期'), findsOneWidget);

      await tester.tap(find.byKey(const Key('semester-selector')));
      await tester.pumpAndSettle();
      await tester.tap(find.text('2026-2027学年第2学期').last);
      await tester.pumpAndSettle();

      final prefs = await SharedPreferences.getInstance();
      final saved = SemesterArchive.fromJson(
        Map<String, dynamic>.from(
          jsonDecode(prefs.getString('semester_archive_v1')!) as Map,
        ),
      );
      expect(saved.activeSemesterId, 's2');
      expect(find.text('2026-2027学年第2学期'), findsOneWidget);
    });

    testWidgets('新建学期后自动切换并保存', (tester) async {
      await pumpApp(tester);

      await tester.tap(find.byKey(const Key('semester-management-menu')));
      await tester.pumpAndSettle();
      await tester.tap(find.text('新建学期'));
      await tester.pumpAndSettle();

      await tester.enterText(
        find.byKey(const Key('semester-create-name')),
        '2027-2028学年第1学期',
      );
      await tester.tap(find.byKey(const Key('semester-create-confirm')));
      await tester.pumpAndSettle();

      expect(find.text('2027-2028学年第1学期'), findsOneWidget);
      final prefs = await SharedPreferences.getInstance();
      final saved = SemesterArchive.fromJson(
        Map<String, dynamic>.from(
          jsonDecode(prefs.getString('semester_archive_v1')!) as Map,
        ),
      );
      expect(saved.activeSemester?.name, '2027-2028学年第1学期');
    });

    testWidgets('无导入历史时撤销菜单项禁用', (tester) async {
      await pumpApp(tester);
      await tester.tap(find.byKey(const Key('semester-management-menu')));
      await tester.pumpAndSettle();

      final undoItem = tester.widget<PopupMenuItem<String>>(
        find.ancestor(
          of: find.text('撤销上次导入'),
          matching: find.byType(PopupMenuItem<String>),
        ),
      );
      expect(undoItem.enabled, isFalse);
    });

    testWidgets('撤销导入操作更新界面并写回本地归档', (tester) async {
      final archive = SemesterArchive(
        activeSemesterId: 's2',
        semesters: [
          SemesterData(id: 's1', name: '原学期'),
          SemesterData(id: 's2', name: '新学期'),
        ],
      );
      archive.recordImport(
        targetId: 's1',
        targetName: '原学期',
        courses: const [],
        unscheduledCourses: const [],
        importedAt: '2026-11-26T10:00:00',
      );
      seedArchive(archive);

      await pumpApp(tester);
      await tester.tap(find.byKey(const Key('semester-management-menu')));
      await tester.pumpAndSettle();
      await tester.tap(find.text('撤销上次导入'));
      await tester.pumpAndSettle();

      final prefs = await SharedPreferences.getInstance();
      final saved = SemesterArchive.fromJson(
        Map<String, dynamic>.from(
          jsonDecode(prefs.getString('semester_archive_v1')!) as Map,
        ),
      );
      expect(saved.canUndoImport, isFalse);
      expect(saved.activeSemesterId, 's2');
      expect(find.text('新学期'), findsOneWidget);
    });

    testWidgets('重建页面后恢复学期选择和撤销记录', (tester) async {
      final archive = SemesterArchive(
        activeSemesterId: 's2',
        semesters: [
          SemesterData(id: 's1', name: '第一学期'),
          SemesterData(id: 's2', name: '第二学期'),
        ],
      );
      archive.recordImport(
        targetId: 's1',
        targetName: '第一学期',
        courses: const [],
        unscheduledCourses: const [],
        importedAt: '2026-11-26T10:00:00',
      );
      SharedPreferences.setMockInitialValues({
        'semester_archive_v1': jsonEncode(archive.toJson()),
      });

      await pumpApp(tester);
      expect(find.text('第一学期'), findsOneWidget);
      expect(find.text('撤销上次导入'), findsNothing);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pumpWidget(const ClassTimeApp());
      await tester.pumpAndSettle();

      expect(find.text('第一学期'), findsOneWidget);
      await tester.tap(find.byKey(const Key('semester-management-menu')));
      await tester.pumpAndSettle();
      final undoItem = tester.widget<PopupMenuItem<String>>(
        find.ancestor(
          of: find.text('撤销上次导入'),
          matching: find.byType(PopupMenuItem<String>),
        ),
      );
      expect(undoItem.enabled, isTrue);
    });
  });
}
