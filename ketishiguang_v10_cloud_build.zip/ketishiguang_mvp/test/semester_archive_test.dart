import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:ketishiguang/data/semester_archive.dart';

Map<String, dynamic> row(String name) => {'name': name};

void main() {
  group('多学期本地归档', () {
    test('旧版单课表迁移到未标注学期，不猜测学期名称', () {
      final archive = SemesterArchive.migrateLegacy(
        courses: [row('旧课程')],
        unscheduledCourses: [row('旧实践课')],
      );

      expect(archive.activeSemesterId, SemesterArchive.legacySemesterId);
      expect(archive.activeSemester?.name, '旧课表（学期未标注）');
      expect(archive.activeSemester?.courses, [row('旧课程')]);
      expect(archive.activeSemester?.unscheduledCourses, [row('旧实践课')]);
      expect(archive.canUndoImport, isFalse);
    });

    test('导入已存在学期后可完整恢复该学期旧课程', () {
      final archive = SemesterArchive(
        activeSemesterId: 's1',
        semesters: [
          SemesterData(
            id: 's1',
            name: '2026-2027学年第1学期',
            courses: [row('旧固定课')],
            unscheduledCourses: [row('旧非固定课')],
          ),
          SemesterData(id: 's2', name: '2026-2027学年第2学期'),
        ],
      );

      archive.recordImport(
        targetId: 's1',
        targetName: '2026-2027学年第1学期',
        courses: [row('新固定课')],
        unscheduledCourses: [row('新非固定课')],
        importedAt: '2026-11-25T12:00:00.000',
      );

      expect(archive.activeSemester?.courses, [row('新固定课')]);
      expect(archive.undoLastImport(), isTrue);
      expect(archive.activeSemesterId, 's1');
      expect(archive.activeSemester?.courses, [row('旧固定课')]);
      expect(archive.activeSemester?.unscheduledCourses, [row('旧非固定课')]);
      expect(archive.canUndoImport, isFalse);
    });

    test('首次导入新学期后撤销会删除新学期并返回导入前学期', () {
      final archive = SemesterArchive(
        activeSemesterId: 'legacy',
        semesters: [
          SemesterData(
            id: 'legacy',
            name: '旧课表（学期未标注）',
            courses: [row('保留课程')],
          ),
        ],
      );

      archive.recordImport(
        targetId: 'semester_2026-2027学年第1学期',
        targetName: '2026-2027学年第1学期',
        courses: [row('新学期课程')],
        unscheduledCourses: const [],
        importedAt: '2026-11-25T12:00:00.000',
      );

      expect(archive.semesters, hasLength(2));
      expect(archive.activeSemester?.name, '2026-2027学年第1学期');
      expect(archive.undoLastImport(), isTrue);
      expect(archive.semesters, hasLength(1));
      expect(archive.activeSemesterId, 'legacy');
      expect(archive.activeSemester?.courses, [row('保留课程')]);
    });

    test('切换学期后撤销导入会返回导入前正在查看的学期', () {
      final archive = SemesterArchive(
        activeSemesterId: 's2',
        semesters: [
          SemesterData(id: 's1', name: '第一学期', courses: [row('A')]),
          SemesterData(id: 's2', name: '第二学期', courses: [row('B')]),
        ],
      );

      archive.recordImport(
        targetId: 's1',
        targetName: '第一学期',
        courses: [row('A2')],
        unscheduledCourses: const [],
        importedAt: '2026-11-25T12:00:00.000',
      );
      expect(archive.activeSemesterId, 's1');
      archive.undoLastImport();
      expect(archive.activeSemesterId, 's2');
      expect(archive.activeSemester?.courses, [row('B')]);
      expect(archive.find('s1')?.courses, [row('A')]);
    });

    test('正常编辑会使旧撤销记录失效，避免覆盖后续修改', () {
      final archive = SemesterArchive.empty();
      archive.recordImport(
        targetId: 'current',
        targetName: '当前课表',
        courses: [row('导入课程')],
        unscheduledCourses: const [],
        importedAt: '2026-11-25T12:00:00.000',
      );
      expect(archive.canUndoImport, isTrue);

      archive.updateActiveData(
        courses: [row('用户后来编辑的课程')],
        unscheduledCourses: const [],
        updatedAt: '2026-11-25T12:01:00.000',
      );

      expect(archive.canUndoImport, isFalse);
      expect(archive.undoLastImport(), isFalse);
      expect(archive.activeSemester?.courses, [row('用户后来编辑的课程')]);
    });

    test('序列化往返保留多个学期与撤销记录', () {
      final archive = SemesterArchive.empty();
      archive.recordImport(
        targetId: 's2',
        targetName: '第二学期',
        courses: [row('课程乙')],
        unscheduledCourses: [row('线上课')],
        importedAt: '2026-11-25T12:00:00.000',
      );

      final encoded = jsonEncode(archive.toJson());
      final restored = SemesterArchive.fromJson(
        Map<String, dynamic>.from(jsonDecode(encoded) as Map),
      );

      expect(restored.semesters, hasLength(2));
      expect(restored.activeSemesterId, 's2');
      expect(restored.activeSemester?.courses, [row('课程乙')]);
      expect(restored.activeSemester?.unscheduledCourses, [row('线上课')]);
      expect(restored.canUndoImport, isTrue);
      expect(restored.undoLastImport(), isTrue);
      expect(restored.activeSemesterId, 'current');
      expect(restored.find('s2'), isNull);
    });

    test('新建重复学期不会覆盖原有学期', () {
      final archive = SemesterArchive.empty();
      expect(archive.createSemester(id: 's2', name: '第二学期'), isTrue);
      archive.find('s2')!.courses = [row('课程')];
      expect(archive.createSemester(id: 's2', name: '第二学期'), isFalse);
      expect(archive.find('s2')?.courses, [row('课程')]);
    });
  });
}
