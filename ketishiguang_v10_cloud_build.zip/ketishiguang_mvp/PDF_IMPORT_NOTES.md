# PDF import implementation notes

## Added
- `lib/import/pdf_course_importer.dart`: Syncfusion PDF text-line/bounds extraction, weekday-column assignment from the weekday header positions, course-block parsing, discrete week expansion, unscheduled course capture, and structured parse issues.
- `main.dart`: PDF selection, import preview, conflict listing, explicit-week persistence, and 11-period timetable grid.
- `test/pdf_week_parser_test.dart`: week-range, odd/even, and discrete-week unit tests.

## Important limitations to validate
- The parser is calibrated against the supplied Wuhan University of Light Industry timetable PDF format. It uses weekday-header horizontal positions and text-line grouping; it still requires Flutter runtime validation against the actual PDF before treating the imported list as authoritative.
- Preview is read-only in this iteration. Manual per-record correction UI is not yet implemented.
- In V5, unscheduled courses are persisted separately in SharedPreferences and exposed through a dedicated list dialog.
- In V5, course kind, campus, room, teacher, and explicit week sets are included in the local `Course` JSON model.
- The existing grid now has 11 rows, but visual polish and period time labels are not calibrated to the school's official timetable.
- Syncfusion Flutter PDF is subject to Syncfusion commercial or Community License terms; confirm eligibility before distribution.


## Conflict detection

- `PdfCourseImporter.findConflicts` reports exact overlapping section ranges per week.
- Conflict detection never deletes, merges, or mutates source meeting records.
- V5 tests both a positive synthetic overlap and the corrected real-PDF baseline (which has no overlap according to the weekday/section/week fields).

## V5 correction after coordinate-level reinspection of the supplied PDF

The supplied PDF pages are rotated 90 degrees at the PDF page level. In the underlying page coordinates, weekday headers are separated along the Y axis, while the course text flow advances along X. The V4 implementation incorrectly used `bounds.left` as the weekday coordinate and used fixed X centers; that could assign records to the wrong weekdays. V5 now:
- Reads all seven weekday header centers and infers whether weekday columns use the X or Y axis.
- Uses the nearest header center with a tolerance derived from the actual header spacing; it does not guess absolute fallback coordinates.
- Processes page 1 and page 2 independently, then sorts each cell along the other coordinate axis.
- Joins wrapped visual lines before extracting slash-delimited fields, preventing truncated room/campus/teacher values.
- Preserves the room text as printed, including old-building aliases.
- Extracts the two non-fixed-time courses from the appendix and persists them locally, including the online flag.

Independent line-level extraction of the supplied three-page PDF with PyMuPDF produced 23 fixed-time records and 2 non-fixed-time records. The corrected weekday assignments include:
- Organic Chemistry III: Thursday 1–2 on even weeks, plus Saturday 5–6 every week.
- Marxism: Wednesday 5–6 and Friday 7–8.
- Chemical Engineering Principles Lab II: Thursday 5–7 / 5–8 on the four specified week groups.
- Biochemistry Lab: Wednesday 7–9.

The previous V4 assertion that Chemical Engineering Principles II and Organic Chemistry III overlap on Wednesday was based on the incorrect weekday mapping and is withdrawn. The 23-record coordinate-checked baseline has no time overlaps under the PDF's explicit weekday/section/week data. Conflict detection remains implemented and has a separate positive unit test to ensure real overlaps are still reported.

A sanitized golden fixture is included at `test/fixtures/expected_schedule.json`. It contains course schedule fields only; the student's name, student number, and original PDF are not included. This fixture is a regression baseline, not a substitute for running the Flutter PDF parser against the original PDF.

## Validation status

- Original PDF: independently inspected at line-level coordinates; 3 pages.
- Golden baseline: 23 fixed-time records, 2 non-fixed-time records.
- Python coordinate extraction: completed and checked against the rendered pages.
- Dart/Flutter compilation and tests: not run in this runtime because Flutter/Dart SDK is unavailable.
- Syncfusion extraction behavior on this exact PDF: still requires device/runtime confirmation.
- Manual per-record correction UI: not implemented yet.
- Syncfusion licensing: confirm Community License eligibility or commercial licensing before distribution.


## V6: editable import review and span-based week grid

- PDF preview now copies parsed meetings into a temporary editable list. The user's existing saved timetable is not touched until they press Confirm.
- Each fixed-time item can be edited (name, weekday, start/end section, explicit weeks, teacher, campus, room, kind, online flag) or removed.
- Each non-fixed-time item can be edited (name, teacher/platform, explicit weeks, note, online flag) or removed.
- Week edits accept continuous ranges and comma-separated individual weeks. The same parser is used for validation, and empty/reversed ranges are rejected.
- Conflict detection is recalculated after every edit. It remains advisory and never auto-removes or merges courses.
- The weekly grid now renders one card spanning its start/end section range. Overlapping courses are assigned side-by-side lanes rather than silently covering one another.
- Tap a saved course card to edit it; long-press to delete it.
- The left section rail labels the morning/afternoon/evening section groups but does not invent bell times.
- These are source-level changes only in this runtime; Flutter compilation and device interaction remain unverified.


## V7 hardening

- Week extraction is now restricted to the substring after the parsed section marker and before `/校区`. This prevents semester identifiers, course codes, and total-hour numbers later in the metadata from being mistaken for week numbers.
- Missing teacher/campus/room fields are surfaced as import-review issues with their original block text; no values are inferred.
- File-picker results with neither in-memory bytes nor a local path now produce a controlled import error instead of force-unwrapping a null path.
- The source archive is intentionally source-only. It does not contain generated `android/` or `ios/` scaffolding; README now documents the one-time `flutter create --platforms=android,ios ...` step.


## V8：多学期归档与导入撤销

- 新增 `lib/data/semester_archive.dart` 纯 Dart 归档模型，负责学期列表、活动学期、固定/非固定课程快照和一次导入撤销记录。
- 新增 `semester_archive_v1` 单键 JSON 持久化，避免把每个学期拆成多组 SharedPreferences 键。
- 首次读取 V7 的 `courses` / `unscheduled_courses` 旧键时，经 `Course` / `UnscheduledCourse` 白名单模型重新序列化后迁移到“旧课表（学期未标注）”，不猜测旧课表属于哪个学期，也不复制未知字段；新归档写入成功后才移除旧键。
- PDF 若识别到学期名称，则按学期归档；若未识别，则导入当前学期。CSV/Excel 导入当前学期。
- 导入确认时保存目标学期导入前快照及导入前活动学期；撤销恢复原目标学期，若目标是新建学期则删除它并返回原活动学期。
- 普通编辑/添加/删除会清除单步撤销，防止撤销覆盖导入后的用户修改；单纯切换学期保留撤销能力。
- 新增 `test/semester_archive_test.dart`，覆盖旧数据迁移、已有学期恢复、新学期删除撤销、切换学期后撤销、编辑使撤销失效、JSON 往返和重复学期保护。


## V9 UI testability

- Added stable keys to the semester selector, semester management menu, and create-semester dialog controls.
- Extracted the PDF import target / replacement warning into `ImportTargetNotice`, so the replacement-vs-create message can be widget-tested independently.
- Added seven widget tests covering semester selection, persistence, semester creation, undo-menu availability, undo behavior, restart restoration, and both import-target notice states.
- The PDF picker-to-preview end-to-end flow remains untested because FilePicker is not injected behind a test seam yet.
