/// Pure-Dart storage model for semester-separated timetable data.
///
/// Course payloads are JSON maps produced by the app's Course and
/// UnscheduledCourse models. This layer deliberately knows nothing about
/// student identity or original PDF files.
class SemesterData {
  final String id;
  final String name;
  List<Map<String, dynamic>> courses;
  List<Map<String, dynamic>> unscheduledCourses;
  String updatedAt;

  SemesterData({
    required this.id,
    required this.name,
    List<Map<String, dynamic>> courses = const [],
    List<Map<String, dynamic>> unscheduledCourses = const [],
    this.updatedAt = '',
  })  : courses = _copyRows(courses),
        unscheduledCourses = _copyRows(unscheduledCourses);

  static List<Map<String, dynamic>> _copyRows(
    List<Map<String, dynamic>> rows,
  ) => rows.map((row) => Map<String, dynamic>.from(row)).toList();

  SemesterData copy() => SemesterData(
        id: id,
        name: name,
        courses: courses,
        unscheduledCourses: unscheduledCourses,
        updatedAt: updatedAt,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'courses': courses,
        'unscheduledCourses': unscheduledCourses,
        'updatedAt': updatedAt,
      };

  factory SemesterData.fromJson(Map<String, dynamic> json) => SemesterData(
        id: '${json['id'] ?? ''}',
        name: '${json['name'] ?? '未命名学期'}',
        courses: _readRows(json['courses']),
        unscheduledCourses: _readRows(json['unscheduledCourses']),
        updatedAt: '${json['updatedAt'] ?? ''}',
      );

  static List<Map<String, dynamic>> _readRows(dynamic value) {
    if (value is! List) return [];
    return value
        .whereType<Map>()
        .map((row) => Map<String, dynamic>.from(row))
        .toList();
  }
}

class SemesterArchive {
  static const schemaVersion = 1;
  static const legacySemesterId = 'legacy-unassigned';

  String activeSemesterId;
  final List<SemesterData> semesters;
  Map<String, dynamic>? lastImportUndo;

  SemesterArchive({
    required this.activeSemesterId,
    required List<SemesterData> semesters,
    this.lastImportUndo,
  }) : semesters = semesters.map((semester) => semester.copy()).toList();

  SemesterData? get activeSemester {
    for (final semester in semesters) {
      if (semester.id == activeSemesterId) return semester;
    }
    return null;
  }

  bool get canUndoImport => lastImportUndo != null;

  static String idForName(String name) {
    final compact = name.trim().replaceAll(RegExp(r'\s+'), '');
    final safe = compact.replaceAll(
      RegExp(r'[^0-9A-Za-z_\-\u4e00-\u9fff]'),
      '_',
    );
    return 'semester_${safe.isEmpty ? 'unnamed' : safe}';
  }

  factory SemesterArchive.empty() => SemesterArchive(
        activeSemesterId: 'current',
        semesters: [SemesterData(id: 'current', name: '当前课表')],
      );

  factory SemesterArchive.migrateLegacy({
    required List<Map<String, dynamic>> courses,
    required List<Map<String, dynamic>> unscheduledCourses,
  }) {
    if (courses.isEmpty && unscheduledCourses.isEmpty) {
      return SemesterArchive.empty();
    }
    return SemesterArchive(
      activeSemesterId: legacySemesterId,
      semesters: [
        SemesterData(
          id: legacySemesterId,
          name: '旧课表（学期未标注）',
          courses: courses,
          unscheduledCourses: unscheduledCourses,
        ),
      ],
    );
  }

  factory SemesterArchive.fromJson(Map<String, dynamic> json) {
    final rows = (json['semesters'] as List? ?? const [])
        .whereType<Map>()
        .map((row) => SemesterData.fromJson(Map<String, dynamic>.from(row)))
        .where((semester) => semester.id.isNotEmpty)
        .toList();
    if (rows.isEmpty) return SemesterArchive.empty();

    final requestedActive = '${json['activeSemesterId'] ?? ''}';
    final active = rows.any((semester) => semester.id == requestedActive)
        ? requestedActive
        : rows.first.id;
    final undo = json['lastImportUndo'];
    return SemesterArchive(
      activeSemesterId: active,
      semesters: rows,
      lastImportUndo: undo is Map ? Map<String, dynamic>.from(undo) : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'schemaVersion': schemaVersion,
        'activeSemesterId': activeSemesterId,
        'semesters': semesters.map((semester) => semester.toJson()).toList(),
        if (lastImportUndo != null)
          'lastImportUndo': Map<String, dynamic>.from(lastImportUndo!),
      };

  SemesterData? find(String id) {
    for (final semester in semesters) {
      if (semester.id == id) return semester;
    }
    return null;
  }

  void setActive(String id) {
    if (find(id) == null) {
      throw ArgumentError.value(id, 'id', 'Semester does not exist');
    }
    activeSemesterId = id;
  }

  /// Persist current in-memory timetable rows into the active semester.
  /// Normal edits invalidate the one-step import undo so it cannot erase them.
  void updateActiveData({
    required List<Map<String, dynamic>> courses,
    required List<Map<String, dynamic>> unscheduledCourses,
    required String updatedAt,
    bool preserveUndo = false,
  }) {
    final active = activeSemester;
    if (active == null) throw StateError('No active semester');
    active.courses = SemesterData._copyRows(courses);
    active.unscheduledCourses = SemesterData._copyRows(unscheduledCourses);
    active.updatedAt = updatedAt;
    if (!preserveUndo) lastImportUndo = null;
  }

  /// Replace a semester's timetable and record enough information for one-step
  /// undo. If the target semester did not exist, undo removes it again.
  void recordImport({
    required String targetId,
    required String targetName,
    required List<Map<String, dynamic>> courses,
    required List<Map<String, dynamic>> unscheduledCourses,
    required String importedAt,
  }) {
    final previousActiveId = activeSemesterId;
    final previousTarget = find(targetId);
    lastImportUndo = {
      'previousActiveSemesterId': previousActiveId,
      'targetSemesterId': targetId,
      'targetExisted': previousTarget != null,
      if (previousTarget != null) 'previousTarget': previousTarget.toJson(),
      'importedAt': importedAt,
    };

    final replacement = SemesterData(
      id: targetId,
      name: targetName,
      courses: courses,
      unscheduledCourses: unscheduledCourses,
      updatedAt: importedAt,
    );
    if (previousTarget == null) {
      semesters.add(replacement);
    } else {
      final index = semesters.indexOf(previousTarget);
      semesters[index] = replacement;
    }
    activeSemesterId = targetId;
  }

  /// Returns false when there is no import to undo.
  bool undoLastImport() {
    final undo = lastImportUndo;
    if (undo == null) return false;

    final targetId = '${undo['targetSemesterId'] ?? ''}';
    final existed = undo['targetExisted'] == true;
    final previousTarget = undo['previousTarget'];
    final index = semesters.indexWhere((semester) => semester.id == targetId);

    if (existed && previousTarget is Map) {
      final restored = SemesterData.fromJson(
        Map<String, dynamic>.from(previousTarget),
      );
      if (index >= 0) {
        semesters[index] = restored;
      } else {
        semesters.add(restored);
      }
    } else if (!existed && index >= 0) {
      semesters.removeAt(index);
    }

    final previousActiveId = '${undo['previousActiveSemesterId'] ?? ''}';
    if (find(previousActiveId) != null) {
      activeSemesterId = previousActiveId;
    } else if (semesters.isNotEmpty) {
      activeSemesterId = semesters.first.id;
    } else {
      final fallback = SemesterData(id: 'current', name: '当前课表');
      semesters.add(fallback);
      activeSemesterId = fallback.id;
    }
    lastImportUndo = null;
    return true;
  }

  /// Create and activate a blank semester. Existing names are not overwritten.
  bool createSemester({required String id, required String name}) {
    if (find(id) != null) return false;
    semesters.add(SemesterData(id: id, name: name));
    activeSemesterId = id;
    lastImportUndo = null;
    return true;
  }
}
