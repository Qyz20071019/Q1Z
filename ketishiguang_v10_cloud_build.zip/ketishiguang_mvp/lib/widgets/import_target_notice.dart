import 'package:flutter/material.dart';

/// Explicitly tells the user which semester a PDF import will write to.
class ImportTargetNotice extends StatelessWidget {
  final String targetName;
  final bool targetExists;

  const ImportTargetNotice({
    super.key,
    required this.targetName,
    required this.targetExists,
  });

  @override
  Widget build(BuildContext context) {
    final status = targetExists
        ? '该学期已存在，将替换该学期原课表；可撤销'
        : '将新建学期；可撤销';
    return Text(
      '导入目标：$targetName（$status）',
      key: const Key('pdf-import-target-notice'),
      style: TextStyle(
        fontSize: 12,
        color: targetExists
            ? Theme.of(context).colorScheme.error
            : Theme.of(context).colorScheme.primary,
      ),
    );
  }
}
