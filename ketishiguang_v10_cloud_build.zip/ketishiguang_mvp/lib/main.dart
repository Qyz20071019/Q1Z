
import 'dart:convert';
import 'dart:io';

import 'package:csv/csv.dart';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'data/semester_archive.dart';
import 'widgets/import_target_notice.dart';
import 'import/pdf_course_importer.dart';

void main() => runApp(const ClassTimeApp());

class Course {
  final String name;
  final String teacher;
  final String room;
  final String campus;
  final String kind;
  final bool online;
  final int weekday; // 1 = Monday
  final int startPeriod;
  final int endPeriod;
  final int startWeek;
  final int endWeek;
  final String weekType; // every, odd, even
  final Set<int> explicitWeeks;

  const Course({
    required this.name,
    this.teacher = '',
    this.room = '',
    this.campus = '',
    this.kind = '讲课',
    this.online = false,
    required this.weekday,
    required this.startPeriod,
    required this.endPeriod,
    this.startWeek = 1,
    this.endWeek = 20,
    this.weekType = 'every',
    this.explicitWeeks = const {},
  });

  Map<String, dynamic> toJson() => {
    'name': name, 'teacher': teacher, 'room': room,
    'campus': campus, 'kind': kind, 'online': online, 'weekday': weekday,
    'startPeriod': startPeriod, 'endPeriod': endPeriod,
    'startWeek': startWeek, 'endWeek': endWeek, 'weekType': weekType,
    'explicitWeeks': explicitWeeks.toList()..sort(),
  };

  Course copyWith({
    String? name,
    String? teacher,
    String? room,
    String? campus,
    String? kind,
    bool? online,
    int? weekday,
    int? startPeriod,
    int? endPeriod,
    int? startWeek,
    int? endWeek,
    String? weekType,
    Set<int>? explicitWeeks,
  }) => Course(
    name: name ?? this.name,
    teacher: teacher ?? this.teacher,
    room: room ?? this.room,
    campus: campus ?? this.campus,
    kind: kind ?? this.kind,
    online: online ?? this.online,
    weekday: weekday ?? this.weekday,
    startPeriod: startPeriod ?? this.startPeriod,
    endPeriod: endPeriod ?? this.endPeriod,
    startWeek: startWeek ?? this.startWeek,
    endWeek: endWeek ?? this.endWeek,
    weekType: weekType ?? this.weekType,
    explicitWeeks: explicitWeeks ?? this.explicitWeeks,
  );

  factory Course.fromJson(Map<String, dynamic> j) => Course(
    name: '${j['name'] ?? ''}', teacher: '${j['teacher'] ?? ''}',
    room: '${j['room'] ?? ''}',
    campus: '${j['campus'] ?? ''}', kind: '${j['kind'] ?? '讲课'}',
    online: j['online'] == true,
    weekday: (j['weekday'] as num).toInt(),
    startPeriod: (j['startPeriod'] as num).toInt(),
    endPeriod: (j['endPeriod'] as num).toInt(),
    startWeek: (j['startWeek'] as num?)?.toInt() ?? 1,
    endWeek: (j['endWeek'] as num?)?.toInt() ?? 20,
    weekType: '${j['weekType'] ?? 'every'}',
    explicitWeeks: ((j['explicitWeeks'] as List?) ?? []).map((e) => (e as num).toInt()).toSet(),
  );
}


class UnscheduledCourse {
  final String name;
  final String teacher;
  final Set<int> weeks;
  final String note;
  final bool online;

  const UnscheduledCourse({
    required this.name,
    required this.teacher,
    required this.weeks,
    required this.note,
    this.online = false,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'teacher': teacher,
    'weeks': weeks.toList()..sort(),
    'note': note,
    'online': online,
  };

  factory UnscheduledCourse.fromJson(Map<String, dynamic> json) =>
      UnscheduledCourse(
        name: '${json['name'] ?? ''}',
        teacher: '${json['teacher'] ?? ''}',
        weeks: ((json['weeks'] as List?) ?? [])
            .map((e) => (e as num).toInt()).toSet(),
        note: '${json['note'] ?? ''}',
        online: json['online'] == true,
      );
}


class PdfReviewResult {
  final List<Course> meetings;
  final List<UnscheduledCourse> unscheduled;

  const PdfReviewResult({
    required this.meetings,
    required this.unscheduled,
  });
}

class ClassTimeApp extends StatelessWidget {
  const ClassTimeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: '课时光',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF426B9A)),
      useMaterial3: true,
      scaffoldBackgroundColor: const Color(0xFFF5F7FA),
    ),
    home: const TimetablePage(),
  );
}

class TimetablePage extends StatefulWidget {
  const TimetablePage({super.key});
  @override
  State<TimetablePage> createState() => _TimetablePageState();
}

class _TimetablePageState extends State<TimetablePage> {
  final List<Course> _courses = [];
  final List<UnscheduledCourse> _unscheduledCourses = [];
  SemesterArchive _archive = SemesterArchive.empty();
  String get _activeSemesterId => _archive.activeSemesterId;
  int _week = 11;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    var loadedArchive = false;
    var legacyReadSafe = true;
    final archiveRaw = prefs.getString('semester_archive_v1');
    if (archiveRaw != null) {
      try {
        _archive = SemesterArchive.fromJson(
          Map<String, dynamic>.from(jsonDecode(archiveRaw) as Map),
        );
        loadedArchive = true;
      } catch (_) {
        // Fall back to the legacy keys below rather than discarding them.
      }
    }

    if (!loadedArchive) {
      List<Map<String, dynamic>> decodeRows(String key) {
        final raw = prefs.getString(key);
        if (raw == null) return [];
        try {
          return (jsonDecode(raw) as List)
              .whereType<Map>()
              .map((row) => Map<String, dynamic>.from(row))
              .toList();
        } catch (_) {
          legacyReadSafe = false;
          return [];
        }
      }

      final legacyCourses = <Map<String, dynamic>>[];
      for (final row in decodeRows('courses')) {
        try {
          // Re-serialize through the allow-listed model so unknown legacy
          // fields (including any accidental identity field) are discarded.
          legacyCourses.add(Course.fromJson(row).toJson());
        } catch (_) {
          legacyReadSafe = false;
        }
      }
      final legacyUnscheduled = <Map<String, dynamic>>[];
      for (final row in decodeRows('unscheduled_courses')) {
        try {
          legacyUnscheduled.add(UnscheduledCourse.fromJson(row).toJson());
        } catch (_) {
          legacyReadSafe = false;
        }
      }
      _archive = SemesterArchive.migrateLegacy(
        courses: legacyCourses,
        unscheduledCourses: legacyUnscheduled,
      );
    }

    _applyActiveSemester();
    await _persistArchive(
      removeLegacyKeys: loadedArchive || legacyReadSafe,
    );
  }

  void _applyActiveSemester() {
    final active = _archive.activeSemester;
    final courses = (active?.courses ?? const <Map<String, dynamic>>[])
        .map(Course.fromJson)
        .toList();
    final unscheduled =
        (active?.unscheduledCourses ?? const <Map<String, dynamic>>[])
            .map(UnscheduledCourse.fromJson)
            .toList();
    if (!mounted) {
      _courses..clear()..addAll(courses);
      _unscheduledCourses..clear()..addAll(unscheduled);
      return;
    }
    setState(() {
      _courses..clear()..addAll(courses);
      _unscheduledCourses..clear()..addAll(unscheduled);
    });
  }

  List<Map<String, dynamic>> _courseRows() =>
      _courses.map((course) => course.toJson()).toList();

  List<Map<String, dynamic>> _unscheduledRows() =>
      _unscheduledCourses.map((course) => course.toJson()).toList();

  Future<void> _persistArchive({bool removeLegacyKeys = false}) async {
    final prefs = await SharedPreferences.getInstance();
    final saved = await prefs.setString(
      'semester_archive_v1',
      jsonEncode(_archive.toJson()),
    );
    if (removeLegacyKeys && saved) {
      await prefs.remove('courses');
      await prefs.remove('unscheduled_courses');
    }
  }

  Future<void> _save({bool preserveUndo = false}) async {
    _archive.updateActiveData(
      courses: _courseRows(),
      unscheduledCourses: _unscheduledRows(),
      updatedAt: DateTime.now().toIso8601String(),
      preserveUndo: preserveUndo,
    );
    await _persistArchive(removeLegacyKeys: true);
  }

  Future<void> _switchSemester(String id) async {
    if (id == _activeSemesterId || _archive.find(id) == null) return;
    _archive.updateActiveData(
      courses: _courseRows(),
      unscheduledCourses: _unscheduledRows(),
      updatedAt: DateTime.now().toIso8601String(),
      preserveUndo: true,
    );
    _archive.setActive(id);
    _applyActiveSemester();
    await _persistArchive(removeLegacyKeys: true);
  }

  Future<void> _commitImport({
    required String targetId,
    required String targetName,
    required List<Course> courses,
    required List<UnscheduledCourse> unscheduled,
  }) async {
    // Keep any unsaved in-memory state as the exact pre-import snapshot.
    _archive.updateActiveData(
      courses: _courseRows(),
      unscheduledCourses: _unscheduledRows(),
      updatedAt: DateTime.now().toIso8601String(),
      preserveUndo: true,
    );
    final importedAt = DateTime.now().toIso8601String();
    _archive.recordImport(
      targetId: targetId,
      targetName: targetName,
      courses: courses.map((course) => course.toJson()).toList(),
      unscheduledCourses:
          unscheduled.map((course) => course.toJson()).toList(),
      importedAt: importedAt,
    );
    _applyActiveSemester();
    await _persistArchive(removeLegacyKeys: true);
  }

  Future<void> _undoLastImport() async {
    if (!_archive.undoLastImport()) {
      _message('没有可以撤销的导入记录。');
      return;
    }
    _applyActiveSemester();
    await _persistArchive(removeLegacyKeys: true);
    final restoredName = _archive.activeSemester?.name ?? '原课表';
    _message('已撤销上次导入，恢复到$restoredName。');
  }

  Future<void> _createSemester() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('新建学期'),
        content: TextField(
          controller: controller,
          autofocus: true,
          key: const Key('semester-create-name'),
          decoration: const InputDecoration(
            labelText: '学期名称',
            hintText: '例如 2027-2028学年第1学期',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('创建', key: Key('semester-create-confirm')),
          ),
        ],
      ),
    );
    controller.dispose();
    if (name == null || name.isEmpty || !mounted) return;
    _archive.updateActiveData(
      courses: _courseRows(),
      unscheduledCourses: _unscheduledRows(),
      updatedAt: DateTime.now().toIso8601String(),
      preserveUndo: true,
    );
    final id = SemesterArchive.idForName(name);
    if (!_archive.createSemester(id: id, name: name)) {
      _message('这个学期已经存在，可以从学期列表切换过去。');
      return;
    }
    _applyActiveSemester();
    await _persistArchive(removeLegacyKeys: true);
    _message('已创建并切换到$name。');
  }

  bool _occurs(Course c) {
    if (c.explicitWeeks.isNotEmpty) return c.explicitWeeks.contains(_week);
    if (_week < c.startWeek || _week > c.endWeek) return false;
    if (c.weekType == 'odd' && _week.isEven) return false;
    if (c.weekType == 'even' && _week.isOdd) return false;
    return true;
  }

  Future<void> _importFile() async {
    setState(() => _busy = true);
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom, allowedExtensions: ['xlsx', 'csv', 'pdf'], withData: true,
      );
      if (result == null) return;
      final file = result.files.single;
      final bytes = file.bytes ?? (file.path == null
          ? null
          : await File(file.path!).readAsBytes());
      if (bytes == null) {
        throw StateError('无法读取所选文件内容，请重新选择 PDF / Excel / CSV 文件。');
      }
      final ext = file.name.toLowerCase().split('.').last;
      if (ext == 'pdf') {
        final parsedResult = await PdfCourseImporter.parse(bytes);
        final review = await _showPdfPreview(parsedResult);
        if (review == null) return;
        if (review.meetings.isEmpty && review.unscheduled.isEmpty) {
          _message('没有识别到可导入的课程；原有课表保持不变。');
        } else {
          final detectedSemester = parsedResult.semester;
          final useDetectedSemester = detectedSemester != '未识别学期';
          final targetName = useDetectedSemester
              ? detectedSemester
              : (_archive.activeSemester?.name ?? '当前课表');
          final targetId = useDetectedSemester
              ? SemesterArchive.idForName(targetName)
              : _activeSemesterId;
          await _commitImport(
            targetId: targetId,
            targetName: targetName,
            courses: review.meetings,
            unscheduled: review.unscheduled,
          );
          _message('已导入到$targetName：${review.meetings.length}条固定时段安排、${review.unscheduled.length}条非固定时段课程；可在菜单中撤销');
        }
      } else {
        final rows = ext == 'csv'
            ? const CsvToListConverter(shouldParseNumbers: false).convert(utf8.decode(bytes))
            : _excelRows(bytes);
        final parsed = _parseRows(rows);
        if (parsed.isEmpty) {
          _message('没有识别到课程。请检查文件格式或使用示例模板。');
        } else {
          await _commitImport(
            targetId: _activeSemesterId,
            targetName: _archive.activeSemester?.name ?? '当前课表',
            courses: parsed,
            unscheduled: const [],
          );
          _message('已导入 ${parsed.length} 条课程安排到当前学期；可在菜单中撤销');
        }
      }
    } catch (e) {
      _message('导入失败：$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }



  Set<int> _courseWeeks(Course course) {
    if (course.explicitWeeks.isNotEmpty) return course.explicitWeeks;
    final weeks = <int>{};
    for (var week = course.startWeek; week <= course.endWeek; week++) {
      if (course.weekType == 'odd' && week.isEven) continue;
      if (course.weekType == 'even' && week.isOdd) continue;
      weeks.add(week);
    }
    return weeks;
  }

  String _formatWeekSet(Set<int> weeks) {
    final sorted = weeks.toList()..sort();
    if (sorted.isEmpty) return '';
    final groups = <String>[];
    var start = sorted.first;
    var previous = start;
    for (final week in sorted.skip(1)) {
      if (week == previous + 1) {
        previous = week;
        continue;
      }
      groups.add(start == previous ? '$start周' : '$start-$previous周');
      start = previous = week;
    }
    groups.add(start == previous ? '$start周' : '$start-$previous周');
    return groups.join('、');
  }

  ImportedMeeting _toImportedMeeting(Course course) => ImportedMeeting(
    courseName: course.name,
    weekday: course.weekday,
    startSection: course.startPeriod,
    endSection: course.endPeriod,
    weeks: _courseWeeks(course),
    teacher: course.teacher,
    room: course.room,
    campus: course.campus,
    kind: course.kind,
    online: course.online,
    sourceText: '课时光本地课程',
  );

  Future<Course?> _editCourse(Course original) async {
    const weekdayNames = ['一', '二', '三', '四', '五', '六', '日'];
    const kinds = ['讲课', '实验', '实践', '上机', '讨论', '其他'];
    final name = TextEditingController(text: original.name);
    final teacher = TextEditingController(text: original.teacher);
    final room = TextEditingController(text: original.room);
    final campus = TextEditingController(text: original.campus);
    final weeks = TextEditingController(text: _formatWeekSet(_courseWeeks(original)));
    var weekday = original.weekday;
    var start = original.startPeriod;
    var end = original.endPeriod;
    var kind = kinds.contains(original.kind) ? original.kind : '其他';
    var online = original.online;
    String? error;

    final edited = await showDialog<Course>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('编辑课程安排'),
          content: SizedBox(
            width: 480,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: name,
                    decoration: const InputDecoration(labelText: '课程名称'),
                  ),
                  TextField(
                    controller: teacher,
                    decoration: const InputDecoration(labelText: '教师'),
                  ),
                  TextField(
                    controller: campus,
                    decoration: const InputDecoration(labelText: '校区'),
                  ),
                  TextField(
                    controller: room,
                    decoration: const InputDecoration(labelText: '教室 / 场地'),
                  ),
                  TextField(
                    controller: weeks,
                    decoration: const InputDecoration(
                      labelText: '上课周次',
                      hintText: '例如 1-16周、18周',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<int>(
                          value: weekday,
                          decoration: const InputDecoration(labelText: '星期'),
                          items: List.generate(7, (i) => DropdownMenuItem(
                            value: i + 1,
                            child: Text('星期${weekdayNames[i]}'),
                          )),
                          onChanged: (value) =>
                              setDialogState(() => weekday = value ?? weekday),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: DropdownButtonFormField<int>(
                          value: start,
                          decoration: const InputDecoration(labelText: '开始节次'),
                          items: List.generate(11, (i) => DropdownMenuItem(
                            value: i + 1,
                            child: Text('第${i + 1}节'),
                          )),
                          onChanged: (value) =>
                              setDialogState(() => start = value ?? start),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: DropdownButtonFormField<int>(
                          value: end,
                          decoration: const InputDecoration(labelText: '结束节次'),
                          items: List.generate(11, (i) => DropdownMenuItem(
                            value: i + 1,
                            child: Text('第${i + 1}节'),
                          )),
                          onChanged: (value) =>
                              setDialogState(() => end = value ?? end),
                        ),
                      ),
                    ],
                  ),
                  DropdownButtonFormField<String>(
                    value: kind,
                    decoration: const InputDecoration(labelText: '课程类型'),
                    items: kinds.map((value) => DropdownMenuItem(
                      value: value,
                      child: Text(value),
                    )).toList(),
                    onChanged: (value) =>
                        setDialogState(() => kind = value ?? kind),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('线上课程'),
                    value: online,
                    onChanged: (value) =>
                        setDialogState(() => online = value),
                  ),
                  if (error != null)
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        error!,
                        style: TextStyle(color: Theme.of(ctx).colorScheme.error),
                      ),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () {
                try {
                  final parsedWeeks =
                      PdfCourseImporter.parseWeekNumbers(weeks.text);
                  if (name.text.trim().isEmpty) {
                    setDialogState(() => error = '课程名称不能为空。');
                    return;
                  }
                  if (parsedWeeks.isEmpty) {
                    setDialogState(() => error = '请填写可识别的周次，例如 1-16周、18周。');
                    return;
                  }
                  if (start > end) {
                    setDialogState(() => error = '结束节次不能早于开始节次。');
                    return;
                  }
                  final sorted = parsedWeeks.toList()..sort();
                  Navigator.pop(ctx, original.copyWith(
                    name: name.text.trim(),
                    teacher: teacher.text.trim(),
                    room: room.text.trim(),
                    campus: campus.text.trim(),
                    kind: kind,
                    online: online,
                    weekday: weekday,
                    startPeriod: start,
                    endPeriod: end,
                    startWeek: sorted.first,
                    endWeek: sorted.last,
                    weekType: 'every',
                    explicitWeeks: parsedWeeks,
                  ));
                } on FormatException catch (e) {
                  setDialogState(() => error = e.message.toString());
                }
              },
              child: const Text('保存修改'),
            ),
          ],
        ),
      ),
    );

    name.dispose();
    teacher.dispose();
    room.dispose();
    campus.dispose();
    weeks.dispose();
    return edited;
  }


  Future<UnscheduledCourse?> _editUnscheduledCourse(
    UnscheduledCourse original,
  ) async {
    final name = TextEditingController(text: original.name);
    final teacher = TextEditingController(text: original.teacher);
    final weeks = TextEditingController(text: _formatWeekSet(original.weeks));
    final note = TextEditingController(text: original.note);
    var online = original.online;
    String? error;

    final edited = await showDialog<UnscheduledCourse>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('编辑非固定时段课程'),
          content: SizedBox(
            width: 440,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: name,
                    decoration: const InputDecoration(labelText: '课程名称'),
                  ),
                  TextField(
                    controller: teacher,
                    decoration: const InputDecoration(labelText: '教师 / 平台'),
                  ),
                  TextField(
                    controller: weeks,
                    decoration: const InputDecoration(
                      labelText: '上课周次',
                      hintText: '例如 4-18周',
                    ),
                  ),
                  TextField(
                    controller: note,
                    maxLines: 3,
                    decoration: const InputDecoration(labelText: '安排说明'),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('线上课程'),
                    value: online,
                    onChanged: (value) =>
                        setDialogState(() => online = value),
                  ),
                  if (error != null)
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        error!,
                        style: TextStyle(color: Theme.of(ctx).colorScheme.error),
                      ),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () {
                try {
                  final parsedWeeks =
                      PdfCourseImporter.parseWeekNumbers(weeks.text);
                  if (name.text.trim().isEmpty || parsedWeeks.isEmpty) {
                    setDialogState(() => error = '课程名称和有效周次不能为空。');
                    return;
                  }
                  Navigator.pop(ctx, UnscheduledCourse(
                    name: name.text.trim(),
                    teacher: teacher.text.trim(),
                    weeks: parsedWeeks,
                    note: note.text.trim(),
                    online: online,
                  ));
                } on FormatException catch (e) {
                  setDialogState(() => error = e.message.toString());
                }
              },
              child: const Text('保存修改'),
            ),
          ],
        ),
      ),
    );

    name.dispose();
    teacher.dispose();
    weeks.dispose();
    note.dispose();
    return edited;
  }

  Future<void> _editExistingCourse(Course original) async {
    final edited = await _editCourse(original);
    if (edited == null || !mounted) return;
    final index = _courses.indexOf(original);
    if (index < 0) return;
    setState(() => _courses[index] = edited);
    await _save();
  }

  Future<void> _deleteCourse(Course course) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除这条课程安排？'),
        content: Text('${course.name} · 周${course.weekday} · ${course.startPeriod}-${course.endPeriod}节'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      setState(() => _courses.remove(course));
      await _save();
    }
  }

  Future<PdfReviewResult?> _showPdfPreview(PdfImportResult result) async {
    const weekdayNames = ['', '一', '二', '三', '四', '五', '六', '日'];
    final editableCourses = result.meetings.map((m) {
      final sortedWeeks = m.weeks.toList()..sort();
      return Course(
        name: m.courseName,
        teacher: m.teacher,
        room: m.room,
        campus: m.campus,
        kind: m.kind,
        online: m.online,
        weekday: m.weekday,
        startPeriod: m.startSection,
        endPeriod: m.endSection,
        startWeek: sortedWeeks.isEmpty ? 1 : sortedWeeks.first,
        endWeek: sortedWeeks.isEmpty ? 20 : sortedWeeks.last,
        explicitWeeks: m.weeks,
      );
    }).toList();
    final unscheduled = result.unscheduled.map((u) => UnscheduledCourse(
      name: u.name,
      teacher: u.teacher,
      weeks: u.weeks,
      note: u.note,
      online: u.online,
    )).toList();

    return showDialog<PdfReviewResult>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          final detectedSemester = result.semester;
          final targetName = detectedSemester == '未识别学期'
              ? (_archive.activeSemester?.name ?? '当前课表')
              : detectedSemester;
          final targetId = detectedSemester == '未识别学期'
              ? _activeSemesterId
              : SemesterArchive.idForName(targetName);
          final targetExists = _archive.find(targetId) != null;
          final conflicts = PdfCourseImporter.findConflicts(
            editableCourses.map(_toImportedMeeting).toList(),
            maxWeek: 30,
          );
          return Dialog(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxWidth: 760,
                maxHeight: MediaQuery.of(ctx).size.height * 0.88,
              ),
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'PDF导入预览 · ${result.semester}',
                      style: Theme.of(ctx).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${editableCourses.length} 条固定时段安排 · ${unscheduled.length} 条非固定时段课程',
                      style: Theme.of(ctx).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 4),
                    ImportTargetNotice(
                      targetName: targetName,
                      targetExists: targetExists,
                    ),
                    const SizedBox(height: 10),
                    if (result.issues.isNotEmpty)
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Theme.of(ctx).colorScheme.errorContainer,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '有 ${result.issues.length} 项内容需要核对。未能识别的内容不会被自动补全。',
                          style: TextStyle(
                            color: Theme.of(ctx).colorScheme.onErrorContainer,
                          ),
                        ),
                      ),
                    Expanded(
                      child: ListView(
                        children: [
                          for (final course in List<Course>.of(editableCourses))
                            Card(
                              child: ListTile(
                                title: Text(course.name),
                                subtitle: Text(
                                  '周${weekdayNames[course.weekday]} '
                                  '${course.startPeriod}-${course.endPeriod}节 · '
                                  '${_formatWeekSet(_courseWeeks(course))}\n'
                                  '${course.teacher} · '
                                  '${course.campus} · '
                                  '${course.room}',
                                ),
                                isThreeLine: true,
                                trailing: Wrap(
                                  spacing: 0,
                                  children: [
                                    IconButton(
                                      tooltip: '编辑此条',
                                      onPressed: () async {
                                        final edited = await _editCourse(course);
                                        if (edited != null) {
                                          setDialogState(() {
                                            final index = editableCourses.indexOf(course);
                                            if (index >= 0) editableCourses[index] = edited;
                                          });
                                        }
                                      },
                                      icon: const Icon(Icons.edit_outlined),
                                    ),
                                    IconButton(
                                      tooltip: '删除此条',
                                      onPressed: () => setDialogState(
                                        () => editableCourses.remove(course),
                                      ),
                                      icon: const Icon(Icons.delete_outline),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          if (unscheduled.isNotEmpty) ...[
                            const Divider(),
                            const Text(
                              '非固定时段课程',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            for (final course in List<UnscheduledCourse>.of(unscheduled))
                              ListTile(
                                contentPadding: EdgeInsets.zero,
                                title: Text(course.name),
                                subtitle: Text(
                                  '${_formatWeekSet(course.weeks)} · ${course.teacher}\n${course.note}',
                                ),
                                isThreeLine: true,
                                trailing: Wrap(
                                  spacing: 0,
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  children: [
                                    if (course.online)
                                      const Chip(label: Text('线上')),
                                    IconButton(
                                      tooltip: '编辑此条',
                                      onPressed: () async {
                                        final edited = await _editUnscheduledCourse(course);
                                        if (edited != null) {
                                          setDialogState(() {
                                            final index = unscheduled.indexOf(course);
                                            if (index >= 0) unscheduled[index] = edited;
                                          });
                                        }
                                      },
                                      icon: const Icon(Icons.edit_outlined),
                                    ),
                                    IconButton(
                                      tooltip: '删除此条',
                                      onPressed: () => setDialogState(
                                        () => unscheduled.remove(course),
                                      ),
                                      icon: const Icon(Icons.delete_outline),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                          if (conflicts.isNotEmpty) ...[
                            const Divider(),
                            Text(
                              '发现 ${conflicts.length} 项时间冲突，请核对：',
                              style: TextStyle(
                                color: Theme.of(ctx).colorScheme.error,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            for (final conflict in conflicts.take(20))
                              Text(
                                conflict.description,
                                style: TextStyle(
                                  color: Theme.of(ctx).colorScheme.error,
                                  fontSize: 12,
                                ),
                              ),
                          ],
                          if (result.issues.isNotEmpty) ...[
                            const Divider(),
                            const Text(
                              '未识别 / 有歧义的原文',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            for (final issue in result.issues)
                              Padding(
                                padding: const EdgeInsets.symmetric(vertical: 4),
                                child: Text(
                                  '${issue.message}\n${issue.sourceText}',
                                  style: const TextStyle(fontSize: 12),
                                ),
                              ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      '点击编辑按钮可逐条修改固定时段和非固定时段课程；删除仅影响本次待导入数据。确认后只保存课程安排，不保存学生身份信息或原始PDF。',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('取消导入'),
                        ),
                        const SizedBox(width: 8),
                        FilledButton(
                          onPressed: editableCourses.isEmpty && unscheduled.isEmpty
                              ? null
                              : () => Navigator.pop(ctx, PdfReviewResult(
                                    meetings: List.unmodifiable(editableCourses),
                                    unscheduled: List.unmodifiable(unscheduled),
                                  )),
                          child: const Text('确认并导入'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _showUnscheduledCourses() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('非固定时段课程'),
        content: SizedBox(
          width: 440,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: _unscheduledCourses.map((course) => Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Expanded(child: Text(
                        course.name,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      )),
                      if (course.online)
                        const Chip(
                          label: Text('线上'),
                          visualDensity: VisualDensity.compact,
                        ),
                    ]),
                    Text('周次：${course.weeks.toList()..sort()}'),
                    if (course.teacher.isNotEmpty)
                      Text('教师：${course.teacher}'),
                    Text(course.note, style: const TextStyle(color: Colors.black54)),
                  ],
                ),
              )).toList(),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  List<List<dynamic>> _excelRows(List<int> bytes) {
    final book = Excel.decodeBytes(bytes);
    if (book.tables.isEmpty) return [];
    final sheet = book.tables.values.first;
    return sheet?.rows.map((r) => r.map((c) => c?.value ?? '').toList()).toList() ?? [];
  }

  // MVP import format: one course per row. Header names can be Chinese or English.
  List<Course> _parseRows(List<List<dynamic>> rows) {
    if (rows.isEmpty) return [];
    String norm(dynamic v) => '$v'.trim().toLowerCase();
    final headers = rows.first.map(norm).toList();
    int col(List<String> names, int fallback) {
      final i = headers.indexWhere(names.contains);
      return i >= 0 ? i : fallback;
    }
    final nameCol = col(['课程名称', '课程', 'name', 'course'], 0);
    final dayCol = col(['星期', '周几', 'weekday', 'day'], 1);
    final startCol = col(['开始节次', '开始节', 'startperiod', 'start'], 2);
    final endCol = col(['结束节次', '结束节', 'endperiod', 'end'], 3);
    final teacherCol = col(['教师', '老师', 'teacher'], 4);
    final roomCol = col(['教室', '地点', 'room'], 5);
    final startWeekCol = col(['开始周', 'startweek'], 6);
    final endWeekCol = col(['结束周', 'endweek'], 7);
    final weekTypeCol = col(['单双周', '周类型', 'weektype'], 8);

    String val(List<dynamic> r, int i) => i < r.length ? '${r[i]}'.trim() : '';
    int number(String s, int fallback) => int.tryParse(RegExp(r'\d+').firstMatch(s)?.group(0) ?? '') ?? fallback;
    final out = <Course>[];
    for (final r in rows.skip(1)) {
      if (r.isEmpty) continue;
      final name = val(r, nameCol);
      if (name.isEmpty || name.toLowerCase() == 'null') continue;
      final dayText = val(r, dayCol);
      final day = number(dayText, 0);
      final start = number(val(r, startCol), 0);
      final end = number(val(r, endCol), start);
      if (day < 1 || day > 7 || start < 1 || start > 11 || end < start || end > 11) continue;
      final wt = val(r, weekTypeCol);
      final type = wt.contains('单') || wt.toLowerCase() == 'odd' ? 'odd'
          : wt.contains('双') || wt.toLowerCase() == 'even' ? 'even' : 'every';
      out.add(Course(
        name: name, weekday: day, startPeriod: start, endPeriod: end,
        teacher: val(r, teacherCol), room: val(r, roomCol),
        startWeek: number(val(r, startWeekCol), 1),
        endWeek: number(val(r, endWeekCol), 20), weekType: type,
      ));
    }
    return out;
  }

  void _message(String s) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  }

  Future<void> _addCourse() async {
    const weekdayLabels = ['一', '二', '三', '四', '五', '六', '日'];
    final name = TextEditingController();
    final room = TextEditingController();
    final teacher = TextEditingController();
    int day = 1, start = 1, end = 2;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('添加课程'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: '课程名称')),
        TextField(controller: teacher, decoration: const InputDecoration(labelText: '教师')),
        TextField(controller: room, decoration: const InputDecoration(labelText: '教室')),
        DropdownButtonFormField<int>(value: day, decoration: const InputDecoration(labelText: '星期'),
          items: List.generate(7, (i) => DropdownMenuItem(value: i + 1, child: Text('星期${weekdayLabels[i]}'))),
          onChanged: (v) => day = v ?? 1),
        Row(children: [
          Expanded(child: DropdownButtonFormField<int>(value: start, decoration: const InputDecoration(labelText: '开始节次'),
            items: List.generate(11, (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}'))),
            onChanged: (v) => start = v ?? 1)),
          const SizedBox(width: 12),
          Expanded(child: DropdownButtonFormField<int>(value: end, decoration: const InputDecoration(labelText: '结束节次'),
            items: List.generate(11, (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}'))),
            onChanged: (v) => end = v ?? 2)),
        ]),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('保存'))],
    ));
    if (ok == true && name.text.trim().isNotEmpty && end >= start) {
      setState(() => _courses.add(Course(name: name.text.trim(), teacher: teacher.text.trim(),
        room: room.text.trim(), weekday: day, startPeriod: start, endPeriod: end)));
      await _save();
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = _courses.where(_occurs).toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('课时光', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: '导入课表',
            onPressed: _busy ? null : _importFile,
            icon: _busy
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.upload_file),
          ),
          PopupMenuButton<String>(
            key: const Key('semester-management-menu'),
            tooltip: '学期管理',
            onSelected: (value) {
              if (value == 'new_semester') _createSemester();
              if (value == 'undo_import') _undoLastImport();
            },
            itemBuilder: (ctx) => [
              const PopupMenuItem(
                value: 'new_semester',
                child: Row(
                  children: [
                    Icon(Icons.add_box_outlined),
                    SizedBox(width: 12),
                    Text('新建学期'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'undo_import',
                enabled: _archive.canUndoImport,
                child: const Row(
                  children: [
                    Icon(Icons.undo),
                    SizedBox(width: 12),
                    Text('撤销上次导入'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addCourse, icon: const Icon(Icons.add), label: const Text('添加课程')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
          child: Row(
            children: [
              Expanded(
                child: DropdownButton<String>(
                  key: const Key('semester-selector'),
                  value: _activeSemesterId,
                  isExpanded: true,
                  underline: const SizedBox.shrink(),
                  items: _archive.semesters
                      .map((semester) => DropdownMenuItem(
                            value: semester.id,
                            child: Text(
                              semester.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) _switchSemester(value);
                  },
                ),
              ),
              const SizedBox(width: 8),
              const Text('第'),
              SizedBox(
                width: 58,
                child: DropdownButton<int>(
                  value: _week,
                  isExpanded: true,
                  items: List.generate(
                    30,
                    (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}')),
                  ),
                  onChanged: (value) => setState(() => _week = value ?? 1),
                ),
              ),
              const Text('周'),
              const SizedBox(width: 8),
              Text(
                '${visible.length}条',
                style: TextStyle(color: Colors.grey.shade700, fontSize: 12),
              ),
            ],
          ),
        ),
        if (_unscheduledCourses.isNotEmpty)
          Align(
            alignment: Alignment.centerRight,
            child: Padding(
              padding: const EdgeInsets.only(right: 12, bottom: 4),
              child: TextButton.icon(
                onPressed: _showUnscheduledCourses,
                icon: const Icon(Icons.event_note, size: 18),
                label: Text('非固定时段 ${_unscheduledCourses.length} 条'),
              ),
            ),
          ),
        Expanded(child: _courses.isEmpty
          ? _emptyState()
          : _weekGrid(visible)),
      ]),
    );
  }

  Widget _emptyState() => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(
    mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.calendar_month, size: 68, color: Colors.blueGrey.shade200),
      const SizedBox(height: 16),
      const Text('还没有课表', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('点击右上角导入 PDF / Excel / CSV，或手动添加课程。',
        textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 18),
      OutlinedButton.icon(onPressed: _importFile, icon: const Icon(Icons.upload_file), label: const Text('导入 PDF / Excel / CSV')),
    ],
  )));



  List<(Course, int)> _layoutDayCourses(List<Course> courses) {
    final sorted = List<Course>.of(courses)
      ..sort((a, b) {
        final byStart = a.startPeriod.compareTo(b.startPeriod);
        if (byStart != 0) return byStart;
        return b.endPeriod.compareTo(a.endPeriod);
      });
    final laneEnds = <int>[];
    final assigned = <Course, int>{};
    for (final course in sorted) {
      var lane = laneEnds.indexWhere((end) => end < course.startPeriod);
      if (lane < 0) {
        lane = laneEnds.length;
        laneEnds.add(course.endPeriod);
      } else {
        laneEnds[lane] = course.endPeriod;
      }
      assigned[course] = lane;
    }
    return sorted.map((course) => (course, assigned[course]!)).toList();
  }

  Widget _weekGrid(List<Course> courses) {
    const weekdayLabels = ['一', '二', '三', '四', '五', '六', '日'];
    const rowHeight = 70.0;
    const gridWidth = 840.0;
    const periodWidth = 54.0;

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: gridWidth,
        child: Column(
          children: [
            SizedBox(
              height: 46,
              child: Row(
                children: [
                  _cell('节次', periodWidth, header: true),
                  ...List.generate(7, (i) => Expanded(
                    child: _cell('周${weekdayLabels[i]}', null, header: true),
                  )),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: SizedBox(
                  height: rowHeight * 11,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: periodWidth,
                        height: rowHeight * 11,
                        child: Column(
                          children: List.generate(11, (i) {
                            final period = i + 1;
                            final phase = period == 1 ? '上午'
                                : period == 5 ? '下午'
                                : period == 9 ? '晚上' : '';
                            return SizedBox(
                              height: rowHeight,
                              child: Container(
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                      color: Colors.blueGrey.shade100,
                                    ),
                                  ),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      '$period',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    if (phase.isNotEmpty)
                                      Text(
                                        phase,
                                        style: TextStyle(
                                          fontSize: 9,
                                          color: Colors.blueGrey.shade600,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            );
                          }),
                        ),
                      ),
                      ...List.generate(7, (dayIndex) {
                        final day = dayIndex + 1;
                        final dayCourses = courses
                            .where((course) => course.weekday == day)
                            .toList();
                        return Expanded(
                          child: _dayColumn(
                            dayCourses,
                            rowHeight: rowHeight,
                          ),
                        );
                      }),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _dayColumn(
    List<Course> courses, {
    required double rowHeight,
  }) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final layout = _layoutDayCourses(courses);
        final laneCount = layout.isEmpty
            ? 1
            : layout.map((entry) => entry.$2).reduce((a, b) => a > b ? a : b) + 1;
        final laneWidth = constraints.maxWidth / laneCount;

        return SizedBox(
          height: rowHeight * 11,
          child: Stack(
            clipBehavior: Clip.hardEdge,
            children: [
              Positioned.fill(
                child: Column(
                  children: List.generate(11, (index) => Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: index.isEven
                            ? const Color(0xFFF8FAFD)
                            : Colors.white,
                        border: Border(
                          bottom: BorderSide(
                            color: Colors.blueGrey.shade100,
                          ),
                          right: BorderSide(
                            color: Colors.blueGrey.shade100,
                          ),
                        ),
                      ),
                    ),
                  )),
                ),
              ),
              for (final entry in layout)
                Positioned(
                  top: (entry.$1.startPeriod - 1) * rowHeight + 3,
                  height: (entry.$1.endPeriod - entry.$1.startPeriod + 1)
                          * rowHeight - 6,
                  left: entry.$2 * laneWidth + 2,
                  width: laneWidth - 4,
                  child: _courseCard(entry.$1),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _courseCard(Course course) {
    final colors = Theme.of(context).colorScheme;
    final background = switch (course.kind) {
      '实验' => colors.tertiaryContainer,
      '实践' => colors.secondaryContainer,
      '上机' => colors.surfaceContainerHighest,
      _ => colors.primaryContainer,
    };
    final foreground = switch (course.kind) {
      '实验' => colors.onTertiaryContainer,
      '实践' => colors.onSecondaryContainer,
      '上机' => colors.onSurface,
      _ => colors.onPrimaryContainer,
    };

    return Tooltip(
      message: '点击编辑 · 长按删除',
      child: Card(
        margin: EdgeInsets.zero,
        elevation: 0.5,
        color: background,
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => _editExistingCourse(course),
          onLongPress: () => _deleteCourse(course),
          child: Padding(
            padding: const EdgeInsets.all(4),
            child: LayoutBuilder(
              builder: (context, constraints) => Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    course.name,
                    maxLines: constraints.maxHeight < 58 ? 2 : 3,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: foreground,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  if (constraints.maxHeight >= 58 && course.room.isNotEmpty)
                    Text(
                      course.room,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: foreground, fontSize: 9),
                    ),
                  if (constraints.maxHeight >= 76 && course.teacher.isNotEmpty)
                    Text(
                      course.teacher,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: foreground, fontSize: 9),
                    ),
                  if (course.online)
                    Text(
                      '线上',
                      style: TextStyle(
                        color: foreground,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _cell(String text, double? width, {bool header = false}) => Container(
    width: width, height: 42, alignment: Alignment.center,
    child: Text(text, style: TextStyle(fontSize: 12,
      fontWeight: header ? FontWeight.bold : FontWeight.normal,
      color: header ? const Color(0xFF426B9A) : Colors.black87)),
  );
}
