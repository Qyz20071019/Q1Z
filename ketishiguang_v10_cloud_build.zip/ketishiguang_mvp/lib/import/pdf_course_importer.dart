import 'dart:typed_data';

import 'package:syncfusion_flutter_pdf/pdf.dart';

/// One occurrence extracted from a single weekday cell in the timetable PDF.
class ImportedMeeting {
  final String courseName;
  final int weekday; // Monday=1 ... Sunday=7
  final int startSection;
  final int endSection;
  final Set<int> weeks;
  final String teacher;
  final String room;
  final String campus;
  final String kind;
  final bool online;
  final String sourceText;

  const ImportedMeeting({
    required this.courseName,
    required this.weekday,
    required this.startSection,
    required this.endSection,
    required this.weeks,
    required this.teacher,
    required this.room,
    required this.campus,
    required this.kind,
    required this.online,
    required this.sourceText,
  });
}

/// A conflict is reported, never auto-resolved: both source records are kept.
class ScheduleConflict {
  final int week;
  final int weekday;
  final int overlapStartSection;
  final int overlapEndSection;
  final ImportedMeeting first;
  final ImportedMeeting second;

  const ScheduleConflict({
    required this.week,
    required this.weekday,
    required this.overlapStartSection,
    required this.overlapEndSection,
    required this.first,
    required this.second,
  });

  String get description =>
      '第$week周 周$weekday ${overlapStartSection}-${overlapEndSection}节：'
      '${first.courseName} / ${second.courseName}';
}

class UnscheduledImportedCourse {
  final String name;
  final Set<int> weeks;
  final String teacher;
  final String note;
  final bool online;

  const UnscheduledImportedCourse(
    this.name,
    this.weeks,
    this.teacher,
    this.note, {
    this.online = false,
  });
}

class ImportIssue {
  final String message;
  final String sourceText;
  const ImportIssue(this.message, this.sourceText);
}

class PdfImportResult {
  final String semester;
  final List<ImportedMeeting> meetings;
  final List<UnscheduledImportedCourse> unscheduled;
  final List<ImportIssue> issues;

  const PdfImportResult({
    required this.semester,
    required this.meetings,
    required this.unscheduled,
    required this.issues,
  });
}

class _PdfLine {
  final int page;
  final double centerX;
  final double centerY;
  final String text;

  const _PdfLine({
    required this.page,
    required this.centerX,
    required this.centerY,
    required this.text,
  });
}

class PdfCourseImporter {
  /// Infer which coordinate axis represents weekday columns.
  ///
  /// In the supplied PDF the page is rotated 90 degrees: weekday headers
  /// share almost the same X coordinate and are separated along Y. Other
  /// timetable PDFs may use the opposite orientation, so this is inferred
  /// from the seven header positions instead of hard-coded coordinates.
  static bool weekdayAxisUsesX(Map<int, ({double x, double y})> headers) {
    final xs = headers.values.map((p) => p.x).toList();
    final ys = headers.values.map((p) => p.y).toList();
    if (xs.isEmpty || ys.isEmpty) return false;
    return _range(xs) > _range(ys);
  }

  static double _range(List<double> values) {
    var low = values.first;
    var high = values.first;
    for (final value in values.skip(1)) {
      if (value < low) low = value;
      if (value > high) high = value;
    }
    return high - low;
  }

  static int nearestWeekday(
    Map<int, double> weekdayCenters,
    double coordinate,
  ) {
    if (weekdayCenters.isEmpty) {
      throw ArgumentError('weekdayCenters cannot be empty');
    }
    var bestDay = weekdayCenters.keys.first;
    var bestDistance = (coordinate - weekdayCenters[bestDay]!).abs();
    for (final entry in weekdayCenters.entries.skip(1)) {
      final distance = (coordinate - entry.value).abs();
      if (distance < bestDistance) {
        bestDay = entry.key;
        bestDistance = distance;
      }
    }
    return bestDay;
  }

  static double _columnTolerance(Map<int, double> centers) {
    final sorted = centers.values.toList()..sort();
    if (sorted.length < 2) return 0;
    var minGap = double.infinity;
    for (var i = 1; i < sorted.length; i++) {
      final gap = sorted[i] - sorted[i - 1];
      if (gap > 0 && gap < minGap) minGap = gap;
    }
    return minGap.isFinite ? minGap * 0.55 : 0;
  }

  /// Extract the week token between the section marker and `/校区` metadata.
  /// Keeping this public makes the boundary rule independently testable.
  static String extractWeekExpression(String compactBlock, int sectionEnd) {
    if (sectionEnd < 0 || sectionEnd > compactBlock.length) {
      throw RangeError.index(sectionEnd, compactBlock, 'sectionEnd');
    }
    final metadataStart = compactBlock.indexOf('/校区', sectionEnd);
    return compactBlock.substring(
      sectionEnd,
      metadataStart < 0 ? compactBlock.length : metadataStart,
    ).trim();
  }

  /// Determine whether the course text flows toward increasing or decreasing
  /// coordinates. This keeps grouping stable if a PDF rotation changes the
  /// coordinate direction while preserving the weekday-axis inference.
  static bool _flowAscending(List<_PdfLine> lines, bool weekdayUsesX) {
    final titles = lines.where((line) =>
        RegExp(r'[★○●◇◆]').hasMatch(line.text) &&
        !RegExp(r'\(\d+\s*-\s*\d+节\)').hasMatch(line.text));
    final details = lines.where((line) =>
        RegExp(r'\(\d+\s*-\s*\d+节\)').hasMatch(line.text));
    var positive = 0;
    var negative = 0;

    double flow(_PdfLine line) =>
        weekdayUsesX ? line.centerY : line.centerX;

    for (final title in titles) {
      _PdfLine? nearest;
      var nearestDistance = double.infinity;
      for (final detail in details) {
        final distance = (flow(detail) - flow(title)).abs();
        if (distance > 0 && distance < nearestDistance) {
          nearest = detail;
          nearestDistance = distance;
        }
      }
      if (nearest == null) continue;
      final difference = flow(nearest) - flow(title);
      if (difference > 0) {
        positive++;
      } else if (difference < 0) {
        negative++;
      }
    }
    if (positive == 0 && negative == 0) return true;
    return positive >= negative;
  }

  static Future<PdfImportResult> parse(Uint8List bytes) async {
    final document = PdfDocument(inputBytes: bytes);
    try {
      final extractor = PdfTextExtractor(document);
      final lines = <_PdfLine>[];

      for (var page = 0; page < document.pages.count; page++) {
        final pageLines = extractor.extractTextLines(
          startPageIndex: page,
          endPageIndex: page,
        );
        for (final line in pageLines) {
          final text = line.text.trim();
          if (text.isEmpty) continue;
          final center = line.bounds.center;
          lines.add(_PdfLine(
            page: page,
            centerX: center.dx,
            centerY: center.dy,
            text: text,
          ));
        }
      }

      final allText = extractor.extractText();
      final semesterMatch = RegExp(r'(\d{4}-\d{4}学年第[一二\d]+学期)')
          .firstMatch(allText);
      final semester = semesterMatch?.group(1) ?? '未识别学期';

      // Find the seven weekday headers on page 1. Never fall back to guessed
      // absolute coordinates: an unrecognized layout must be surfaced.
      final headerPoints = <int, ({double x, double y})>{};
      for (final line in lines.where((l) => l.page == 0)) {
        final match = RegExp(r'星期([一二三四五六日天])').firstMatch(line.text);
        if (match == null) continue;
        const dayMap = {
          '一': 1, '二': 2, '三': 3, '四': 4,
          '五': 5, '六': 6, '日': 7, '天': 7,
        };
        headerPoints[dayMap[match.group(1)]!] =
            (x: line.centerX, y: line.centerY);
      }

      final issues = <ImportIssue>[];
      if (headerPoints.length != 7) {
        issues.add(ImportIssue(
          '未能从第一页识别完整的星期一至星期日标题（识别到${headerPoints.length}/7列）。',
          lines.where((l) => l.page == 0 && l.text.contains('星期'))
              .map((l) => l.text).join('\n'),
        ));
        return PdfImportResult(
          semester: semester,
          meetings: const [],
          unscheduled: _parseUnscheduled(allText),
          issues: List.unmodifiable(issues),
        );
      }

      final useX = weekdayAxisUsesX(headerPoints);
      final weekdayCenters = <int, double>{
        for (final entry in headerPoints.entries)
          entry.key: useX ? entry.value.x : entry.value.y,
      };
      final tolerance = _columnTolerance(weekdayCenters);
      if (tolerance <= 0) {
        issues.add(const ImportIssue(
          '星期标题坐标无法确定列间距，未尝试猜测课程所属星期。',
          '请确认 PDF 是否为教务系统导出的原始课表。',
        ));
        return PdfImportResult(
          semester: semester,
          meetings: const [],
          unscheduled: _parseUnscheduled(allText),
          issues: List.unmodifiable(issues),
        );
      }

      final meetings = <ImportedMeeting>[];
      // The supplied timetable grid is split across pages 1 and 2. Process
      // each page independently so the second page cannot reorder the first.
      final gridPageCount = document.pages.count < 2 ? document.pages.count : 2;
      for (var page = 0; page < gridPageCount; page++) {
        for (var day = 1; day <= 7; day++) {
          final cellLines = lines.where((line) {
            if (line.page != page) return false;
            if (line.text.contains('实践课程') ||
                line.text.contains('其他课程') ||
                line.text.contains('时间段') ||
                line.text.contains('节次') ||
                line.text.contains('星期') ||
                line.text == '上午' ||
                line.text == '下午' ||
                line.text == '晚上') {
              return false;
            }
            final coordinate = useX ? line.centerX : line.centerY;
            final nearest = nearestWeekday(weekdayCenters, coordinate);
            return nearest == day &&
                (coordinate - weekdayCenters[day]!).abs() <= tolerance;
          }).toList();

          final flowAscending = _flowAscending(cellLines, useX);
          cellLines.sort((a, b) {
            final aFlow = useX ? a.centerY : a.centerX;
            final bFlow = useX ? b.centerY : b.centerX;
            return flowAscending
                ? aFlow.compareTo(bFlow)
                : bFlow.compareTo(aFlow);
          });

          final blocks = _splitCourseBlocks(cellLines);
          for (final block in blocks) {
            try {
              final meeting = _parseBlock(block, day);
              if (meeting != null) {
                meetings.add(meeting);
                final missingFields = <String>[];
                if (meeting.teacher.isEmpty) missingFields.add('教师');
                if (meeting.campus.isEmpty) missingFields.add('校区');
                if (meeting.room.isEmpty) missingFields.add('场地');
                if (missingFields.isNotEmpty) {
                  issues.add(ImportIssue(
                    '${meeting.courseName}：未从 PDF 中提取到${missingFields.join('、')}字段，请人工核对。',
                    block.map((l) => l.text).join('\n'),
                  ));
                }
              }
            } catch (e) {
              issues.add(ImportIssue(
                '$e',
                block.map((l) => l.text).join('\n'),
              ));
            }
          }
        }
      }

      if (meetings.isEmpty) {
        issues.add(const ImportIssue(
          '没有从星期列识别到固定时段课程。坐标方向或课程块格式可能与当前解析规则不符。',
          '没有使用固定坐标猜测星期；请检查 PDF 版式。',
        ));
      }

      return PdfImportResult(
        semester: semester,
        meetings: List.unmodifiable(meetings),
        unscheduled: _parseUnscheduled(allText),
        issues: List.unmodifiable(issues),
      );
    } finally {
      document.dispose();
    }
  }

  static List<List<_PdfLine>> _splitCourseBlocks(List<_PdfLine> lines) {
    final blocks = <List<_PdfLine>>[];
    List<_PdfLine>? current;
    final titleMarker = RegExp(r'[★○●◇◆]');

    for (final line in lines) {
      final text = line.text.trim();
      final isTitle = titleMarker.hasMatch(text) &&
          !text.contains('课程学时') &&
          !text.contains('教学班组成');
      if (isTitle) {
        if (current != null && current.isNotEmpty) blocks.add(current);
        current = <_PdfLine>[line];
      } else if (current != null) {
        current.add(line);
      }
    }
    if (current != null && current.isNotEmpty) blocks.add(current);
    return blocks;
  }

  static ImportedMeeting? _parseBlock(List<_PdfLine> block, int day) {
    // The PDF wraps fields over several visual lines. Join without a newline
    // before extracting slash-delimited fields, otherwise room/campus values
    // are silently truncated at each line break.
    final compact = block.map((l) => l.text.trim()).join('');
    final source = block.map((l) => l.text.trim()).join('\n');

    final title = block.first.text
        .replaceFirst(RegExp(r'^\s*\d+\s*[|｜]?\s*'), '')
        .replaceAll(RegExp(r'[★○●◇◆]'), '')
        .replaceAll(RegExp(r'^[|｜]\s*'), '')
        .trim();
    if (title.isEmpty) return null;

    final section = RegExp(r'\((\d+)\s*-\s*(\d+)\s*节\)')
        .firstMatch(compact);
    if (section == null) {
      throw FormatException('未识别节次：$title');
    }
    final start = int.parse(section.group(1)!);
    final end = int.parse(section.group(2)!);
    if (start < 1 || end > 11 || start > end) {
      throw FormatException('节次超出1-11或范围无效：$title $start-$end');
    }

    // Parse only the timetable's week-expression segment between the
    // section marker and the first metadata field. Parsing the entire block
    // can accidentally pick up digits from course codes, semester IDs,
    // total hours, or teaching-class identifiers when the week text is bad.
    final weekExpression = extractWeekExpression(compact, section.end);
    final weeks = parseWeekNumbers(weekExpression);
    if (weeks.isEmpty) {
      throw FormatException('未识别周次：$title（原文：$weekExpression）');
    }

    String field(String name) {
      final match = RegExp('$name\\s*[:：]\\s*([^/]+)').firstMatch(compact);
      return match?.group(1)?.trim() ?? '';
    }

    final room = field('场地');
    final campus = field('校区');
    final teacher = field('教师');
    final titleLine = block.first.text;
    final kind = titleLine.contains('○') ? '实验'
        : titleLine.contains('●') ? '实践'
        : titleLine.contains('◇') ? '上机'
        : titleLine.contains('◆') ? '讨论' : '讲课';

    return ImportedMeeting(
      courseName: title,
      weekday: day,
      startSection: start,
      endSection: end,
      weeks: Set.unmodifiable(weeks),
      teacher: teacher,
      room: room,
      campus: campus,
      kind: kind,
      online: false,
      sourceText: source,
    );
  }

  static List<UnscheduledImportedCourse> _parseUnscheduled(String allText) {
    final result = <UnscheduledImportedCourse>[];

    final practice = RegExp(
      r'认识实习\s*[●]?\s*([^(/;；]+).*?第\s*\d+\s*周',
      dotAll: true,
    ).firstMatch(allText);
    if (practice != null) {
      final weeks = parseWeekNumbers(practice.group(0)!);
      if (weeks.isNotEmpty) {
        result.add(UnscheduledImportedCourse(
          '认识实习',
          Set.unmodifiable(weeks),
          practice.group(1)?.trim() ?? '',
          '实践课程；原 PDF 未指定星期和节次',
        ));
      }
    }

    final online = RegExp(
      r'民族手工艺术（通识）\s*[★○●◇◆]?\s*([^(/;；]+).*?线上课程',
      dotAll: true,
    ).firstMatch(allText);
    if (online != null) {
      final weeks = parseWeekNumbers(online.group(0)!);
      if (weeks.isNotEmpty) {
        result.add(UnscheduledImportedCourse(
          '民族手工艺术（通识）',
          Set.unmodifiable(weeks),
          online.group(1)?.trim() ?? '',
          '楚课联盟线上课程；上课方式及时间另行通知',
          online: true,
        ));
      }
    }
    return List.unmodifiable(result);
  }

  /// Finds overlapping meetings week by week. It does not delete, merge,
  /// or modify either source meeting.
  static List<ScheduleConflict> findConflicts(
    List<ImportedMeeting> meetings, {
    int maxWeek = 30,
  }) {
    final conflicts = <ScheduleConflict>[];
    for (var week = 1; week <= maxWeek; week++) {
      for (var day = 1; day <= 7; day++) {
        final active = meetings
            .where((m) => m.weekday == day && m.weeks.contains(week))
            .toList();
        for (var i = 0; i < active.length; i++) {
          for (var j = i + 1; j < active.length; j++) {
            final a = active[i];
            final b = active[j];
            final start = a.startSection > b.startSection
                ? a.startSection : b.startSection;
            final end = a.endSection < b.endSection
                ? a.endSection : b.endSection;
            if (start <= end) {
              conflicts.add(ScheduleConflict(
                week: week,
                weekday: day,
                overlapStartSection: start,
                overlapEndSection: end,
                first: a,
                second: b,
              ));
            }
          }
        }
      }
    }
    return List.unmodifiable(conflicts);
  }

  static Set<int> parseWeekNumbers(String raw) {
    final text = raw
        .replaceAll('（', '(')
        .replaceAll('）', ')')
        .replaceAll(RegExp(r'[－—~～至]'), '-')
        .replaceAll(RegExp(r'共\s*\d+\s*周'), ' ');

    final weeks = <int>{};
    final ranges = RegExp(
      r'(\d+)\s*-\s*(\d+)\s*周(?:\s*\(\s*(单|双)\s*\))?',
    );
    final masked = text.replaceAllMapped(ranges, (match) {
      final start = int.parse(match.group(1)!);
      final end = int.parse(match.group(2)!);
      if (start > end) {
        throw FormatException('周次范围倒置：${match[0]}');
      }
      for (var week = start; week <= end; week++) {
        final parity = match.group(3);
        if (parity == '单' && week.isEven) continue;
        if (parity == '双' && week.isOdd) continue;
        weeks.add(week);
      }
      return ' ' * match[0]!.length;
    });

    for (final match in RegExp(r'(?:第\s*)?(\d+)\s*周').allMatches(masked)) {
      weeks.add(int.parse(match.group(1)!));
    }
    return weeks;
  }
}
